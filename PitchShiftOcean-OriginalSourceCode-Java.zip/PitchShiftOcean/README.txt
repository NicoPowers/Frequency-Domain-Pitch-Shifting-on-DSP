This is the reference implementation (in Java) of the Ocean Pitch Shifting algorithm described in the following paper:

N. Juillerat, B. Hirsbrunner, "Low Latency Audio Pitch Shifting in the Frequency Domain",
IEEE International Conference on Audio, Language and Image Processing, ICALIP 2010, 2010.


In the 'build' folder, you can find the already compiled executable as a small command line tool.
Use: "java -jar PitchShiftOcean.jar -h" to dump all command line options.
You will need to install a Java Runtime Environment. Download it at www.java.com
Only .wav, .aiff and .au audio files are supported. Default options are tuned for 44.1 kHz music.

In the 'src' folder, you can find the Java source code.
It has been tested with Java version 8 and Eclipse version 4.6.3 (Neon).
