Sources of the Tachyon-Tunnel library can be found at
https://sourceforge.net/projects/tachyon-sonics/

Sources of the tritonus-sampled library can be found at
http://www.tritonus.org/
