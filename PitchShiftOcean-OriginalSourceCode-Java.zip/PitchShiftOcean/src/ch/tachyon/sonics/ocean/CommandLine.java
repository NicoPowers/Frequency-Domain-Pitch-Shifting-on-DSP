package ch.tachyon.sonics.ocean;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;

import javax.sound.sampled.AudioFileFormat;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.UnsupportedAudioFileException;

import ch.tachyon.tunnel.audio.file.AudioFileIO;
import ch.tachyon.tunnel.audio.file.AudioFileTypes;
import ch.tachyon.tunnel.common.IMultiChanAudioSource;
import ch.tachyon.tunnel.host.StreamProcessor;
import ch.tachyon.tunnel.host.effect.IPullEffect;

public class CommandLine {
	
	private File inputFile;
	private File outputFile;
	private Double pitchShiftRatio = null;
	private int blockSize = 2048;
	private int overlap = 4;
	private int zeroPad = 2;
	
	
	private void parseArgs(String[] args) {
		if (args.length == 0)
			dumpUsageAndExit();
		if (args.length == 1 && args[0].equals("-h"))
			dumpOptionsAndExit();
		int i = 0;
		while (i < args.length) {
			String arg = args[i];
			if (arg.equals("-i")) {
				inputFile = new File(args[++i]);
			} else if (arg.equals("-o")) {
				outputFile = new File(args[++i]);
			} else if (arg.equals("-r")) {
				pitchShiftRatio = Double.parseDouble(args[++i]);
			} else if (arg.equals("-b")) {
				blockSize = Integer.parseInt(args[++i]);
			} else if (arg.equals("-v")) {
				overlap = Integer.parseInt(args[++i]);
			} else if (arg.equals("-m")) {
				zeroPad = Integer.parseInt(args[++i]);
			} else {
				System.err.println("Ignoring unkown option: " + arg);
			}
			i++;
		}
	}
	
	private void dumpUsageAndExit() {
		System.out.println("Usage: java -jar PitchShiftOcean.jar -i <input file> -r <pitch shift ratio> -o <output file>");
		System.out.println("Use \"java -jar PitchShiftOcean.jar -h\" to dump all options");
		System.exit(1);
	}
	
	private void dumpOptionsAndExit() {
		System.out.println("Usage: java -jar PitchShiftOcean.jar -i <input file> -r <pitch shift ratio> -o <output file> "
				+ "[-b <blockSize>] [-v <overlap>] [-m <zero padding>]");
		System.out.println(" -i <input file>: input audio file to transform. Only .wav, .au and .aiff are supported");
		System.out.println(" -o <output file>: output audio file in which to save the result. Only .wav, .au and .aiff are supported");
		System.out.println(" -r <pitch shift ratio>: the pitch shifting ratio, between 0.5 and 2. Values less than 1 lower the pitch. Values greater than 1 raise the pitch");
		System.out.println(" -b <block size>: allowed values are 512, 1024, 2048 (default), 4096 and 8192. Higher values result in higher frequency resolution, but also higher latency and slower processing");
		System.out.println(" -v <overlap>: allowed values are 2, 4 (default), 8 and 16. Higher values result in higher quality, but slower processing");
		System.out.println(" -m <zero padding>: allowed values are 1 (none), 2 (default), 4 and 8. Higer values result in better frequency accuracy, but slower processing");
		System.out.println(" -h: displays this help");
		System.exit(0);
	}
	
	private void validateArgs() {
		if (inputFile == null) {
			System.err.println("No input file specified");
			System.exit(1);
		}
		if (outputFile == null) {
			System.err.println("No output file specified");
			System.exit(1);
		}
		if (pitchShiftRatio == null) {
			System.err.println("No pitch shift ratio specified");
			System.exit(1);
		}
		if (Double.isNaN(pitchShiftRatio) || pitchShiftRatio < 0.5 || pitchShiftRatio > 2.0) {
			System.err.println("Invalid pitch shift ratio. Allowed range: 0.5 - 2.0");
			System.exit(1);
		}
		if (blockSize < 512 || blockSize > 8192 || (blockSize & (blockSize - 1)) != 0) {
			System.err.println("Invalid block size. Allowed values: 512, 1024, 2048, 4096, 8192");
			System.exit(1);
		}
		if (overlap < 2 || overlap > 16 || (overlap & (overlap - 1)) != 0) {
			System.err.println("Invalid overlap. Allowed values: 2, 4, 8, 16");
			System.exit(1);
		}
		if (zeroPad < 1 || zeroPad > 8 || (zeroPad & (zeroPad - 1)) != 0) {
			System.err.println("Invalid zero padding (m). Allowed values: 1, 2, 4, 8");
			System.exit(1);
		}
        if (!inputFile.isFile()) {
            System.err.println("Cannot find input file " + inputFile);
            System.exit(1);
        }

        if (outputFile.exists()) {
            System.out.print("Output file already exists, replace it [y/n]? ");
            System.out.flush();
            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
            try {
                String answer = reader.readLine();
                if (!"y".equalsIgnoreCase(answer.trim()))
                    System.exit(1);
            } catch (IOException ex) {
                ex.printStackTrace();
                System.exit(1);
            }
        }
	}
	
	private void processFile() {
        AudioFileFormat.Type outputType = AudioFileTypes.instance().getWritableType4ext(outputFile.getName());
        if (outputType == null) {
            System.err.println("Unsupported output audio file format. Try using WAVE (*.wav), AIFF/AIFC (*.aif) or Sun Audio (*.au) files");
            System.exit(1);
        }

        try {
            System.out.println("Loading file " + inputFile + "...");
            AudioFileFormat inputFormat = AudioFileTypes.instance().getAudioFileFormat(inputFile, true);
            System.out.println("Sample rate: " + ((int) inputFormat.getFormat().getSampleRate()));

            IMultiChanAudioSource fileSource = AudioFileIO.createAudioSource(inputFile);
            StreamProcessor processor = new StreamProcessor(inputFormat);
            IPullEffect plugin = processor.getPlugin(PitchShiftOcean.class);
            plugin.setParameterValue("pitchShiftRatio", pitchShiftRatio);
            plugin.setParameterValue("logBlockSize", blockSize);
            plugin.setParameterValue("logOverlap", overlap);
            plugin.setParameterValue("logZeroPad", zeroPad);
            IMultiChanAudioSource transformedSource = processor.filter(fileSource, plugin);
            AudioFileFormat format = new AudioFileFormat(outputType,
                    new AudioFormat(inputFormat.getFormat().getSampleRate(), 16, inputFormat.getFormat().getChannels(), true, true),
                    (int) processor.getLength());

            System.out.println("Processing...");
            AudioFileIO.saveAudioFile(transformedSource, outputFile, format, null);
        } catch (UnsupportedAudioFileException ex) {
            System.err.println("Unsupported input audio file format. Try using WAVE (*.wav), AIFF/AIFC (*.aif) or Sun Audio (*.au) files");
            System.exit(1);
        } catch (IOException e) {
            System.err.println("There was an unexpected I/O error");
            e.printStackTrace(System.err);
            System.exit(1);
        }

        System.out.println("Successful. Output file " + outputFile);
	}
	
	public static void main(String[] args) {
		CommandLine cmd = new CommandLine();
		cmd.parseArgs(args);
		cmd.validateArgs();
		cmd.processFile();
	}

}
